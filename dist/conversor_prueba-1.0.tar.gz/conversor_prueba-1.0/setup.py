from setuptools import setup

setup(
    name="conversor_prueba",
    version="1.0",
    py_modules=["convertidor"],
    install_requires=["colorama"],
    entry_points={
        "console_scripts": [
            "conversor=convertidor:main",
        ],
    },
)
